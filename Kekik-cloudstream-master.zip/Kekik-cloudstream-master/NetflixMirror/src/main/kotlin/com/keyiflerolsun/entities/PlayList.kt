package com.keyiflerolsun.entities

class PlayList : ArrayList<PlayListItem>()
