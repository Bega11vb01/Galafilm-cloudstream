package com.keyiflerolsun.entities

data class Episode(
    val complate: String,
    val ep: String,
    val id: String,
    val s: String,
    val t: String,
    val time: String
)
