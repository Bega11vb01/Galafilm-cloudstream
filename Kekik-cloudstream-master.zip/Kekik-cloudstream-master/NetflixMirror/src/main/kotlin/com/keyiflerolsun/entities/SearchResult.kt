package com.keyiflerolsun.entities

data class SearchResult(
    val id: String,
    val t: String
)
